import React from 'react';
import RootNavigator from './src/navigation/rootNavigator';

function App() {
	return <RootNavigator />;
}

export default App;
