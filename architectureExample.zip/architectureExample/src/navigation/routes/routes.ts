export enum Routes {
	ExampleScreen = '/example-screen',
}
