import React from 'react';
import ExampleScreen from '../../screens/ExampleScreen/ExampleScreen';

function ExampleContainer() {
	return <ExampleScreen />;
}

export default ExampleContainer;
